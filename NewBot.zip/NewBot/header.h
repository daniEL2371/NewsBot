
class pair{
	private string 
	pri

	pair(){
	
	}
}