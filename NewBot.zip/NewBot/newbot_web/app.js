var express =  require('express');
//var expressSession = require("express-session");
var app = new express();
var fs = require('fs');
var bodyParser = require("body-parser");


var news;


// middlewares

//app.use(session({secret: "Your secret key"}));
app.use(express.static("public"));
app.use(express.static("node_modules/bootstrap/dist/"));
app.use(bodyParser.urlencoded( {extended: true } ));



//Get method


app.get("/getnews", function(req, res) {
	fs.readFile("../news.json", "utf8", function(error, data) {
		if (error) {
			console.log("server failed reading json!")
			return;
		}
		news = JSON.parse(data.trim());
	});
	//console.log(news.length);
	res.header("Content-Type: applicatioin/json");
	res.status(200).send(news);
});

app.listen(3000, function() {
	console.log("server listining on port 3000!")
});

