/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newbot;

/**
 *
 * @author Daniel Zelalem
 * ATR/2026/08
 */

import java.io.FileReader;
import static java.lang.System.setProperty;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import java.io.FileWriter;
import java.io.IOException;
import org.json.simple.parser.JSONParser; 
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

public class NewBot {
    private static final String PATH_LOCAL_NEWS = "./news.json";
    private static final String PATH_LOCAL_NEWS_LINKS = "./links.json";
    /**
     * @param args the command line arguments
     */
    //setProperty("webdriver.chrome.driver","C:\\Users\\hp255-g3\\Downloads\\selinium\\chromedriver.exe");
    static ChromeDriver  driver;
    static JSONArray newsList;
    
    public static void main(String[] args) throws IOException, ParseException {
        newsList = importNews();
        fetchNewsFromAddisFourtune();
        
    }
    public static void fetchNewsFromAddisFourtune() throws IOException, ParseException {
        setProperty("webdriver.chrome.driver","C:\\Users\\hp255-g3\\Downloads\\selinium\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://addisfortune.net/");
        WebElement container = driver.findElementById("addisfortune-main");
        WebElement body = container.findElement(By.className("row")).findElement(By.className("span6")).findElement(By.className("row")).findElement(By.className("span6"));
        while (true) {
            List<WebElement> headers = body.findElements(By.tagName("h3"));
            List<WebElement> allNews = body.findElements(By.className("row"));
 
            System.out.println("All headers found on web page are: " + headers.size() + " links");
 
        
            for (int i=0; i< headers.size(); i++ ) {
                String title = headers.get(i).findElement(By.tagName("a")).getText();
                String link = headers.get(i).findElement(By.tagName("a")).getAttribute("href");
                String src = allNews.get(i).findElement(By.tagName("img")).getAttribute("src");
                String content = allNews.get(i).findElement(By.tagName("p")).getText();

               /*System.out.println(title);
               System.out.println(link);
               System.out.println(src);
               System.out.println(content);*/
                if (!newsList.contains(link)) {
                    writeNewsToJson(title, link, src, content);
                    newsList.add(link);
                }
             
              
            }
            try {
                Thread.sleep(1000 *  2 * 60);
            } catch(Exception ex) {
                ex.printStackTrace();
            }
        }
        
        
    }
    public static void writeNewsToJson(String title, String link, String src, String content) throws IOException, ParseException {
        JSONParser parser = new JSONParser();
        JSONArray list = (JSONArray) parser.parse(new FileReader(PATH_LOCAL_NEWS));  
        JSONObject jsonObj = new JSONObject();
        jsonObj.put("title", title);
        jsonObj.put("imgsrc", src);
        jsonObj.put("text", content);
        jsonObj.put("link", link);
        
        list.add(jsonObj);
        
        try (FileWriter file = new FileWriter(PATH_LOCAL_NEWS)) {
            file.write(list.toJSONString());
            file.close();
        }
        addNewsLink(link);
        
        
        
        
    }
    public static JSONArray importNews() throws IOException, ParseException {
        JSONParser parser = new JSONParser();
        JSONArray list = (JSONArray) parser.parse(new FileReader(PATH_LOCAL_NEWS_LINKS)); 
        return list;
    }
    public static void addNewsLink(String link)throws IOException, ParseException {
        JSONParser parser = new JSONParser();
        JSONArray list = (JSONArray) parser.parse(new FileReader(PATH_LOCAL_NEWS_LINKS));
        list.add(link);
        try (FileWriter file = new FileWriter(PATH_LOCAL_NEWS_LINKS)) {
            file.write(list.toJSONString());
            file.close();
        }
    }
    
}
